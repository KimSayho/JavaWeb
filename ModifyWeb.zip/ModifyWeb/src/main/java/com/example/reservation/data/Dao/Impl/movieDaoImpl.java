package com.example.reservation.data.Dao.Impl;

public interface movieDaoImpl {
}
