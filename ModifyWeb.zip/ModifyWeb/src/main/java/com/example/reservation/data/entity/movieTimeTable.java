package com.example.reservation.data.entity;

public class movieTimeTable {
}
