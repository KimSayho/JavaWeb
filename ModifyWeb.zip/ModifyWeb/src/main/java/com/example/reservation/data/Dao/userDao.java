package com.example.reservation.data.Dao;

public interface userDao {
}
