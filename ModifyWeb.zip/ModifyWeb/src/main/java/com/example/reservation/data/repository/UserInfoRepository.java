package com.example.reservation.data.repository;

import com.example.reservation.data.entity.userTable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserInfoRepository extends JpaRepository<userTable, Long> {
}
