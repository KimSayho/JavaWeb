package com.example.reservation.data.entity;

import java.time.LocalTime;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(
        name = "movieInfo"
)
public class movieTable {
    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY
    )
    private Integer movieID;
    @Column(
            nullable = false
    )
    private String movieName;
    @Column(
            nullable = false
    )
    private String movieRated;
    @Column(
            nullable = false
    )
    private String movieGenre;
    @Column(
            nullable = false
    )
    private String movieActor;
    @Column(
            nullable = false
    )
    private String movieDirector;
    @Column(
            nullable = false
    )
    private String movieStory;
    @Column(
            nullable = false
    )
    private LocalTime movieTime;
    @Column(
            nullable = false
    )
    private float movieScore;

    public Integer getMovieID() {
        return this.movieID;
    }

    public String getMovieName() {
        return this.movieName;
    }

    public String getMovieRated() {
        return this.movieRated;
    }

    public String getMovieGenre() {
        return this.movieGenre;
    }

    public String getMovieActor() {
        return this.movieActor;
    }

    public String getMovieDirector() {
        return this.movieDirector;
    }

    public String getMovieStory() {
        return this.movieStory;
    }

    public LocalTime getMovieTime() {
        return this.movieTime;
    }

    public float getMovieScore() {
        return this.movieScore;
    }

    public void setMovieID(final Integer movieID) {
        this.movieID = movieID;
    }

    public void setMovieName(final String movieName) {
        this.movieName = movieName;
    }

    public void setMovieRated(final String movieRated) {
        this.movieRated = movieRated;
    }

    public void setMovieGenre(final String movieGenre) {
        this.movieGenre = movieGenre;
    }

    public void setMovieActor(final String movieActor) {
        this.movieActor = movieActor;
    }

    public void setMovieDirector(final String movieDirector) {
        this.movieDirector = movieDirector;
    }

    public void setMovieStory(final String movieStory) {
        this.movieStory = movieStory;
    }

    public void setMovieTime(final LocalTime movieTime) {
        this.movieTime = movieTime;
    }

    public void setMovieScore(final float movieScore) {
        this.movieScore = movieScore;
    }

    public movieTable() {
    }

    public movieTable(final Integer movieID, final String movieName, final String movieRated, final String movieGenre, final String movieActor, final String movieDirector, final String movieStory, final LocalTime movieTime, final float movieScore) {
        this.movieID = movieID;
        this.movieName = movieName;
        this.movieRated = movieRated;
        this.movieGenre = movieGenre;
        this.movieActor = movieActor;
        this.movieDirector = movieDirector;
        this.movieStory = movieStory;
        this.movieTime = movieTime;
        this.movieScore = movieScore;
    }
}

