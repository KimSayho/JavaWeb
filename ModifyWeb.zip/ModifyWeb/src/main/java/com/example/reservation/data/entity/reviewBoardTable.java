package com.example.reservation.data.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(
        name = "BoardMgmt"
)
public class reviewBoardTable {
    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY
    )
    private Integer reviewBoardNumber;
    @Column(
            nullable = false
    )
    private Integer reviewNumber;
    @Column(
            nullable = false
    )
    private Integer userId;
    @Column(
            nullable = false
    )
    private String reviewName;
    @Column(
            nullable = false
    )
    private String reviewDetail;
    @Column(
            nullable = false
    )
    private float movieEvaluation;

    public Integer getReviewBoardNumber() {
        return this.reviewBoardNumber;
    }

    public Integer getReviewNumber() {
        return this.reviewNumber;
    }

    public Integer getUserId() {
        return this.userId;
    }

    public String getReviewName() {
        return this.reviewName;
    }

    public String getReviewDetail() {
        return this.reviewDetail;
    }

    public float getMovieEvaluation() {
        return this.movieEvaluation;
    }

    public void setReviewBoardNumber(final Integer reviewBoardNumber) {
        this.reviewBoardNumber = reviewBoardNumber;
    }

    public void setReviewNumber(final Integer reviewNumber) {
        this.reviewNumber = reviewNumber;
    }

    public void setUserId(final Integer userId) {
        this.userId = userId;
    }

    public void setReviewName(final String reviewName) {
        this.reviewName = reviewName;
    }

    public void setReviewDetail(final String reviewDetail) {
        this.reviewDetail = reviewDetail;
    }

    public void setMovieEvaluation(final float movieEvaluation) {
        this.movieEvaluation = movieEvaluation;
    }

    public reviewBoardTable() {
    }

    public reviewBoardTable(final Integer reviewBoardNumber, final Integer reviewNumber, final Integer userId, final String reviewName, final String reviewDetail, final float movieEvaluation) {
        this.reviewBoardNumber = reviewBoardNumber;
        this.reviewNumber = reviewNumber;
        this.userId = userId;
        this.reviewName = reviewName;
        this.reviewDetail = reviewDetail;
        this.movieEvaluation = movieEvaluation;
    }
}