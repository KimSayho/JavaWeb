package com.example.reservation.data.repository;

import com.example.reservation.data.entity.movieTable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface movieReservationRepository extends JpaRepository<movieTable, Long> {
}
