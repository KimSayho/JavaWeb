package com.example.reservation.data.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(
        name = "reservateionMgmt"
)
public class reservationTable {
    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY
    )
    private Integer reservationNumber;
    @Column(
            nullable = false
    )
    private Integer movieInfoID;
    @Column(
            nullable = false
    )
    private Integer seatNumber;

    public Integer getReservationNumber() {
        return this.reservationNumber;
    }

    public Integer getMovieInfoID() {
        return this.movieInfoID;
    }

    public Integer getSeatNumber() {
        return this.seatNumber;
    }

    public void setReservationNumber(final Integer reservationNumber) {
        this.reservationNumber = reservationNumber;
    }

    public void setMovieInfoID(final Integer movieInfoID) {
        this.movieInfoID = movieInfoID;
    }

    public void setSeatNumber(final Integer seatNumber) {
        this.seatNumber = seatNumber;
    }

    public reservationTable() {
    }

    public reservationTable(final Integer reservationNumber, final Integer movieInfoID, final Integer seatNumber) {
        this.reservationNumber = reservationNumber;
        this.movieInfoID = movieInfoID;
        this.seatNumber = seatNumber;
    }
}