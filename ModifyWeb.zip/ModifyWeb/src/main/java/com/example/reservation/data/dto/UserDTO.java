package com.example.reservation.data.dto;

public class UserDTO {
    private String id;
    private String password;
    private String nickname;
    private String Pnum;

    public UserDTO() {
    }

    public String getId() {
        return this.id;
    }

    public String getPassword() {
        return this.password;
    }

    public String getNickname() {
        return this.nickname;
    }

    public String getPnum() {
        return this.Pnum;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public void setPassword(final String password) {
        this.password = password;
    }

    public void setNickname(final String nickname) {
        this.nickname = nickname;
    }

    public void setPnum(final String Pnum) {
        this.Pnum = Pnum;
    }

    public String toString() {
        String var10000 = this.getId();
        return "UserDTO(id=" + var10000 + ", password=" + this.getPassword() + ", nickname=" + this.getNickname() + ", Pnum=" + this.getPnum() + ")";
    }
}