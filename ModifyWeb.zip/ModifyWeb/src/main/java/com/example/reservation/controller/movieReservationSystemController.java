package com.example.reservation.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class movieReservationSystemController {
    public movieReservationSystemController() {
    }

    @GetMapping({"/login"})
    public String show_menu() {
        return "/login";
    }
}
