package com.example.reservation.controller;

import com.example.reservation.data.dto.UserDTO;
import com.example.reservation.data.entity.userTable;
import com.example.reservation.data.repository.UserInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class UserInfoController {
    @Autowired
    UserInfoRepository userInfoRepository;

    public UserInfoController() {
    }

    @GetMapping({"/"})
    public String show_menu() {
        return "/";
    }

    @GetMapping({"/register"})
    public String get_input(Model model) {
        UserDTO user = new UserDTO();
        model.addAttribute("user", user);
        return "/register";
    }

    @PostMapping({"/register"})
    public String submitForm(@ModelAttribute("user") UserDTO userDto) {
        userTable setUser = new userTable();
        setUser.setId(userDto.getId());
        setUser.setPassword(userDto.getPassword());
        setUser.setNickname(userDto.getNickname());
        setUser.setPnum(userDto.getPnum());
        this.userInfoRepository.save(setUser);
        return "/index";
    }
}