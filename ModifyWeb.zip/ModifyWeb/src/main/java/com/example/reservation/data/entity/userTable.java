
package com.example.reservation.data.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(
        name = "user"
)
public class userTable {
    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY
    )
    private String id;
    @Column(
            nullable = false
    )
    private String password;
    @Column(
            nullable = false
    )
    private String nickname;
    @Column(
            nullable = false
    )
    private String Pnum;

    public String getId() {
        return this.id;
    }

    public String getPassword() {
        return this.password;
    }

    public String getNickname() {
        return this.nickname;
    }

    public String getPnum() {
        return this.Pnum;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public void setPassword(final String password) {
        this.password = password;
    }

    public void setNickname(final String nickname) {
        this.nickname = nickname;
    }

    public void setPnum(final String Pnum) {
        this.Pnum = Pnum;
    }

    public userTable() {
    }

    public userTable(final String id, final String password, final String nickname, final String Pnum) {
        this.id = id;
        this.password = password;
        this.nickname = nickname;
        this.Pnum = Pnum;
    }
}