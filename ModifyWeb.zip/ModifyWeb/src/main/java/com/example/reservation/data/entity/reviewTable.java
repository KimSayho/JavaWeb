package com.example.reservation.data.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(
        name = "review"
)
public class reviewTable {
    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY
    )
    private Integer reviewNumber;
    @Column(
            nullable = false
    )
    private Integer movieID;
    @Column(
            nullable = false
    )
    private String movieName;

    public Integer getReviewNumber() {
        return this.reviewNumber;
    }

    public Integer getMovieID() {
        return this.movieID;
    }

    public String getMovieName() {
        return this.movieName;
    }

    public void setReviewNumber(final Integer reviewNumber) {
        this.reviewNumber = reviewNumber;
    }

    public void setMovieID(final Integer movieID) {
        this.movieID = movieID;
    }

    public void setMovieName(final String movieName) {
        this.movieName = movieName;
    }

    public reviewTable() {
    }

    public reviewTable(final Integer reviewNumber, final Integer movieID, final String movieName) {
        this.reviewNumber = reviewNumber;
        this.movieID = movieID;
        this.movieName = movieName;
    }
}