package com.example.modifyweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModifyWebApplicationTests {

    @Test
    void contextLoads() {
    }

}
